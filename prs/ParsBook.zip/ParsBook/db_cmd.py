import sqlite3


def create_tables():
    db_file = "db.db"
    conn = sqlite3.connect(db_file)
    cur = conn.cursor()
    with conn:
        cur.execute(f"""CREATE TABLE IF NOT EXISTS books(
                name TEXT NOT NULL,    
                date TEXT NOT NULL,                               
                city TEXT NOT NULL,
                img TEXT NOT NULL,
                result TEXT NOT NULL
        )""")


def new_entry(_name, _date, _city, _img, _result):
    db_file = "astro.db"
    conn = None
    #try:
    sql = f"""INSERT INTO astro (name, date, city, img, result) VALUES (?,?,?,?,?)"""
    conn = sqlite3.connect(db_file)
    cur = conn.cursor()
    cur.execute(sql, (_name, _date, _city, _img, _result))
    conn.commit()
    cur.close()
    # except Exception as ex:
    #     print("new_entry: ", ex)
    # finally:
    #     if conn is not None:
    #         conn.close()

create_tables()