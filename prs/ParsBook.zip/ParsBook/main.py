import selenium
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import db_cmd


# options
options = Options()
options.headless = False
driver = webdriver.Chrome(options = options)
try:
    driver.get('http://book-online.com.ua/')
    form_name = driver.find_elements(By.XPATH, "/html/body/div[1]/div[3]/table/tbody/tr[2]/td[2]/table/tbody/tr/td[2]/div/div[1]/table/tbody/tr[1]/td/h2/a")
    for i in form_name:
        name = i.text
        print(type(name), "---", name)


except Exception as ex:
    print("Exception: ", ex)
finally:
    driver.close()


# name = "Иван"  # input("Ввдите имя: ")
# date = "03/Январь/1985"  # input("Ввдите дату(dd/месяц/yyyy): ")
# city = "ЗАПОРОЖЬЕ"  # input("Ввдите город: ")
# #_______________________________________________
# options = Options()
# options.headless = False
# driver = webdriver.Chrome(options=options)
# driver.get('https://astro-online.ru/natal.html%27')
# #_______________________________________________
# form = driver.find_element(By.NAME, "u_namez")
# form.send_keys(name)
# form = driver.find_element(By.NAME, "dayz")
# day = date.split("/")[0]
# if day[0] == "0":
#     day = day[1]
# form.send_keys(day)
# form.send_keys(date.split("/")[0])
# form = driver.find_element(By.NAME, "monthz")
# form.send_keys(date.split("/")[1])
# form = driver.find_element(By.XPATH, f"//select[@name='city']/option[text()='{city}']")
# form.click()
# form = driver.find_element(By.NAME, "yearz")
# form.send_keys(date.split("/")[2])
# form.submit()
#
# form_img = driver.find_element(By.CLASS_NAME, "current_img").get_attribute("src")
# form_txt = driver.find_elements(By.XPATH, "//div[@id='pln_in_sign']/div")
# text = []
# text_out = []
# for i in form_txt:
#     text.append(i.text)
# count = -1
# for i in text:
#     count += 1
#     for j in i.split(" "):
#         if j == "Луна":
#             text_out.append(text[count])
#             text_out.append(text[count + 1])
# db_cmd.new_entry(name, date, city, form_img, text_out[1])

#
# import urllib
# from selenium import webdriver
#
# driver = webdriver.Firefox()
# driver.get('http://www.google.com/recaptcha/demo/recaptcha')
#
# # get the image source
# img = driver.find_element_by_xpath('//div[@id="recaptcha_image"]/img')
# src = img.get_attribute('src')
#
# # download the image
# urllib.urlretrieve(src, "captcha.png")
#
# driver.close()